INSERT INTO History(CellNumber, OldState, NewState, DateModify) VALUES (31, 1, 2, '2020-05-27');
INSERT INTO History(CellNumber, OldState, NewState, DateModify) VALUES (942, 1, 7, '2020-05-24');
INSERT INTO History(CellNumber, OldState, NewState, DateModify) VALUES (942, 7, 1, '2020-05-27');

INSERT INTO BaseStations(CellNumber, CellName, StateID) VALUES (942, 'Пограничники', 1);
INSERT INTO BaseStations(CellNumber, CellName, StateID) VALUES (25, 'Метро Шевченко', 3);

INSERT INTO States(StateNumber, StateName) VALUES (16, 'Одесская');
INSERT INTO States(StateNumber, StateName) VALUES (10, 'Киевская');
INSERT INTO States(StateNumber, StateName) VALUES (16, 'Львовская');



