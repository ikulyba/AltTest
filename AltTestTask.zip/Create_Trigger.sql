USE [TestDB]
GO

/****** Object:  Trigger [dbo].[Cell_AU]    Script Date: 28.05.2020 11:03:42 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		<Author: Ivan Kulyba>
-- Create date: <Create Date: 27.05.2020>
-- Description:	<Description: >
-- =============================================
CREATE TRIGGER [dbo].[Cell_AU] ON  [dbo].[BaseStations] 
   AFTER UPDATE
AS 
DECLARE @Old_State int;
DECLARE	@New_State int;
DECLARE @CellNum int;
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for trigger here
	SELECT @Old_State = StateID, @CellNum = CellNumber from DELETED;
	SELECT @New_State = StateID from INSERTED;
	IF @Old_State != @New_State
	BEGIN
        INSERT INTO dbo.History(CellNumber, OldState, NewState, DateModify)
	        VALUES (@CellNum, @Old_State, @New_State, GETDATE());
    END
END
GO

ALTER TABLE [dbo].[BaseStations] ENABLE TRIGGER [Cell_AU]
GO


