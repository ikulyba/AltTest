USE [TestDB]
GO

/****** Object:  Table [dbo].[BaseStations]    Script Date: 28.05.2020 10:59:45 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[BaseStations](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[CellNumber] [int] NULL,
	[CellName] [varchar](50) NULL,
	[StateID] [int] NOT NULL,
 CONSTRAINT [PK_BaseStations] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[BaseStations]  WITH CHECK ADD  CONSTRAINT [FK_BaseStations] FOREIGN KEY([StateID])
REFERENCES [dbo].[States] ([ID])
ON DELETE CASCADE
GO

ALTER TABLE [dbo].[BaseStations] CHECK CONSTRAINT [FK_BaseStations]
GO


USE [TestDB]
GO

/****** Object:  Table [dbo].[History]    Script Date: 28.05.2020 11:01:20 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[History](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[CellNumber] [int] NULL,
	[OldState] [int] NULL,
	[NewState] [int] NULL,
	[DateModify] [date] NULL,
 CONSTRAINT [PK_History] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO


USE [TestDB]
GO

/****** Object:  Table [dbo].[States]    Script Date: 28.05.2020 11:01:45 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[States](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[StateNumber] [int] NULL,
	[StateName] [varchar](50) NULL,
 CONSTRAINT [PK_States] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO


